---
title: Scribbles & Scrabbles
tags:
categories:
date: 2023-09-25
lastMod: 2023-09-25
---
Personal [live coding]({{< ref "/pages/live coding" >}}) journal to share scribbles and scrabbles.
