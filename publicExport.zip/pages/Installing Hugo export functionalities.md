---
title: Installing Hugo export functionalities
tags:
categories:
date: 2023-09-26
lastMod: 2023-09-26
---


I keep trying on with workflows...

But I keep failing to trigger an action from a push from another github action.
